import { useEffect, useState, useRef } from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";

import MandantDetail from "./pages/MandantDetail";
import MandantForm from "./components/MandantForm";

import {
  getMandanten,
  getHeute,
  getEmpfehlungen,
  getKpis,
  getDecisions,
  addMandantAPI,
  updateMandantAPI,
  deleteMandantAPI
} from "./api";

// ==============================
// 🎨 UI COMPONENTS
// ==============================

const Card = ({ children, color = "#ddd" }) => (
  <div style={{
    background: "#fff",
    padding: "16px",
    borderRadius: "14px",
    borderLeft: `6px solid ${color}`,
    boxShadow: "0 4px 10px rgba(0,0,0,0.06)"
  }}>
    {children}
  </div>
);

const Section = ({ title, children }) => (
  <div style={{ marginTop: "30px" }}>
    <h2>{title}</h2>
    <div style={{ display: "grid", gap: "12px" }}>
      {children}
    </div>
  </div>
);

// ==============================
// 🚀 APP
// ==============================

function App() {

  // ==============================
  // 📊 STATE
  // ==============================

  const [mandanten, setMandanten] = useState({});
  const [heute, setHeute] = useState([]);
  const [empfehlungen, setEmpfehlungen] = useState([]);
  const [kpis, setKpis] = useState([]);
  const [decisions, setDecisions] = useState([]);

  const [selectedMandant, setSelectedMandant] = useState(null);
  const [formLoading, setFormLoading] = useState(false);

  const [loading, setLoading] = useState(true);
  const [notifications, setNotifications] = useState([]);

  const shownNotifications = useRef({});

  // ==============================
  // 🔔 NOTIFICATIONS
  // ==============================

  const addNotification = (text) => {
    if (!text) return;
    if (shownNotifications.current[text]) return;

    shownNotifications.current[text] = true;

    const id = Date.now();

    setNotifications(prev => [...prev, { id, text }]);

    setTimeout(() => {
      setNotifications(prev => prev.filter(n => n.id !== id));
    }, 4000);
  };

  // ==============================
  // 📥 LOAD FUNCTIONS
  // ==============================

  const ladeMandanten = async () => {
    try {
      const data = await getMandanten();
      setMandanten(data || {});
    } catch {
      addNotification("❌ Mandanten Fehler");
      setMandanten({});
    }
  };

  const ladeHeute = async () => {
    try {
      const data = await getHeute();
      setHeute(data || []);
    } catch {
      setHeute([]);
    }
  };

  const ladeEmpfehlungen = async () => {
    try {
      const data = await getEmpfehlungen();
      setEmpfehlungen((data || []).filter(e => e?.empfehlungen?.length));
    } catch {
      setEmpfehlungen([]);
    }
  };

  const ladeKpis = async () => {
    try {
      const data = await getKpis();
      setKpis(data || []);
    } catch {
      setKpis([]);
    }
  };

  const ladeDecisions = async () => {
    try {
      const data = await getDecisions();
      setDecisions(data || []);
    } catch {
      setDecisions([]);
    }
  };

  // ==============================
  // 🔄 LOAD ALL (SMART)
  // ==============================

  const ladeAlles = async (first = false) => {
    try {
      if (first) setLoading(true);

      await Promise.all([
        ladeMandanten(),
        ladeHeute(),
        ladeEmpfehlungen(),
        ladeKpis(),
        ladeDecisions()
      ]);

    } finally {
      if (first) setLoading(false);
    }
  };

  // ==============================
  // 🚀 AUTO REFRESH (SAFE)
  // ==============================

  useEffect(() => {
    ladeAlles(true);

    const interval = setInterval(() => {
      // ❌ KEIN RELOAD während Edit / Submit
      if (!formLoading) {
        ladeAlles(false);
      }
    }, 5000);

    return () => clearInterval(interval);
  }, [selectedMandant, formLoading]);

  // ==============================
  // 🧠 SMART TEXT
  // ==============================

  const getSmartText = (k) => {
    if (!k) return "";

    if (k.aufgaben_ueberfaellig > 0) return "🔴 Sofort handeln";
    if (k.tage_ohne_antwort >= 7) return "📞 Kontakt nötig";
    if (k.umsatz > 5000) return "💰 High Value";

    return "🟢 Stabil";
  };

  // ==============================
  // 👤 CRUD (ROBUST)
  // ==============================

  const handleCreate = async (data) => {
    try {
      setFormLoading(true);

      await addMandantAPI(data);

      addNotification("✅ Mandant erstellt");

      await ladeAlles();

    } catch (e) {
      addNotification("❌ " + e.message);
    } finally {
      setFormLoading(false);
    }
  };

  const handleUpdate = async (data) => {
    try {
      setFormLoading(true);

      await updateMandantAPI(selectedMandant, data);

      addNotification("✏️ Aktualisiert");

      setSelectedMandant(null);

      await ladeAlles();

    } catch (e) {
      addNotification("❌ " + e.message);
    } finally {
      setFormLoading(false);
    }
  };

  const handleDelete = async (name) => {
    if (!window.confirm(`Mandant "${name}" wirklich löschen?`)) return;

    try {
      await deleteMandantAPI(name);

      addNotification("🗑️ Gelöscht");

      if (selectedMandant === name) {
        setSelectedMandant(null);
      }

      await ladeAlles();

    } catch (e) {
      addNotification("❌ " + e.message);
    }
  };

  // ==============================
  // 🏠 DASHBOARD
  // ==============================

  const Dashboard = () => {

    if (loading) {
      return <p style={{ padding: "20px" }}>Lade...</p>;
    }

    return (
      <div style={{
        padding: "20px",
        fontFamily: "Arial",
        background: "#f5f7fa",
        minHeight: "100vh"
      }}>

        <h1>🔥 Kanzlei Dashboard</h1>

        {/* FORM */}
        <Section title={selectedMandant ? "✏️ Bearbeiten" : "➕ Neuer Mandant"}>
          <MandantForm
            initialData={selectedMandant ? mandanten[selectedMandant] || null : null}
            onSubmit={selectedMandant ? handleUpdate : handleCreate}
            onCancel={() => setSelectedMandant(null)}
            loading={formLoading}
          />
        </Section>

        {/* HEUTE */}
        <Section title="🚨 Heute">
          {heute.length === 0 && <p>Alles ruhig 👍</p>}
          {heute.map((t, i) => (
            <Card key={i} color="#2196f3">
              {t.text}
            </Card>
          ))}
        </Section>

        {/* KPI */}
        <Section title="📊 Status">
          {kpis.length === 0 && <p>Keine Daten</p>}

          {kpis.map((k, i) => {

            let color = "#4caf50";
            if (k.aufgaben_ueberfaellig > 0) color = "#f44336";

            return (
              <Card key={i} color={color}>

                <Link to={`/mandant/${k.mandant}`}>
                  <strong>{k.mandant}</strong>
                </Link>

                <br />
                {getSmartText(k)}

                <br />

                <button onClick={() => setSelectedMandant(k.mandant)}>
                  ✏️
                </button>

                <button onClick={() => handleDelete(k.mandant)}>
                  🗑️
                </button>

              </Card>
            );
          })}
        </Section>

        {/* MANDANTEN */}
        <Section title="👥 Alle Mandanten">
          {Object.keys(mandanten).length === 0 && <p>Keine Mandanten</p>}

          {Object.keys(mandanten).map(name => (
            <Card key={name}>
              <Link to={`/mandant/${name}`}>{name}</Link>
              <br />
              <small>{mandanten[name]?.email || "keine Email"}</small>
            </Card>
          ))}
        </Section>

      </div>
    );
  };

  // ==============================
  // ROUTER
  // ==============================

  return (
    <Router>

      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/mandant/:name" element={<MandantDetail />} />
      </Routes>

      {/* 🔔 NOTIFICATIONS */}
      <div style={{
        position: "fixed",
        top: "20px",
        right: "20px",
        zIndex: 9999
      }}>
        {notifications.map(n => (
          <div key={n.id} style={{
            background: "#333",
            color: "white",
            padding: "12px",
            marginBottom: "10px",
            borderRadius: "10px"
          }}>
            {n.text}
          </div>
        ))}
      </div>

    </Router>
  );
}

export default App;