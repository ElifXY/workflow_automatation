import { useEffect, useState } from "react";
import { Link } from "react-router-dom";

function Dashboard() {

  const [mandanten, setMandanten] = useState({});
  const [name, setName] = useState("");
  const [umsatz, setUmsatz] = useState("");

  // ==============================
  // DATEN LADEN
  // ==============================

  const ladeMandanten = async () => {
    try {
      const res = await fetch("http://127.0.0.1:8000/mandanten");
      const data = await res.json();

      setMandanten(data.data || data);

    } catch (err) {
      console.error("Fehler beim Laden:", err);
    }
  };

  // ==============================
  // MANDANT ERSTELLEN
  // ==============================

  const addMandant = async () => {
    if (!name) {
      alert("Name fehlt");
      return;
    }

    try {
      const res = await fetch("http://127.0.0.1:8000/mandanten", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          name: name,
          umsatz: parseFloat(umsatz) || 0
        })
      });

      const result = await res.json();

      if (result.error) {
        alert(result.error);
        return;
      }

      setName("");
      setUmsatz("");

      ladeMandanten();

    } catch (err) {
      console.error("Fehler beim Erstellen:", err);
      alert("Server nicht erreichbar");
    }
  };

  // ==============================
  // INIT
  // ==============================

  useEffect(() => {
    ladeMandanten();
  }, []);

  // ==============================
  // UI
  // ==============================

  return (
    <div style={{ padding: "20px", fontFamily: "Arial" }}>
      <h1>Kanzlei Dashboard</h1>

      {/* MANDANTEN */}
      <h2>Mandanten</h2>

      <ul>
        {Object.entries(mandanten).map(([name, m]) => (
          <li key={name}>
            <Link to={`/mandant/${name}`}>
              {name} – {m.umsatz}€
            </Link>
          </li>
        ))}
      </ul>

      {Object.keys(mandanten).length === 0 && (
        <p>Keine Mandanten vorhanden</p>
      )}

      {/* NEUER MANDANT */}
      <h3>Neuer Mandant</h3>

      <input
        placeholder="Name"
        value={name}
        onChange={(e) => setName(e.target.value)}
      />

      <input
        placeholder="Umsatz"
        value={umsatz}
        onChange={(e) => setUmsatz(e.target.value)}
      />

      <button onClick={addMandant}>
        Hinzufügen
      </button>
    </div>
  );
}

export default Dashboard;