const BASE_URL = "http://127.0.0.1:8000";

// ==============================
// 🔥 GENERIC FETCH (ULTRA ROBUST)
// ==============================

const apiFetch = async (url, options = {}) => {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 8000);

  try {
    const res = await fetch(BASE_URL + url, {
      ...options,
      signal: controller.signal
    });

    clearTimeout(timeout);

    let data = null;

    try {
      data = await res.json();
    } catch {
      data = null;
    }

    if (!res.ok) {
      const message =
        data?.detail ||
        `Server Fehler (${res.status})`;

      throw new Error(message);
    }

    return data;

  } catch (err) {
    console.error("❌ API Fehler:", err.message);

    if (err.name === "AbortError") {
      throw new Error("⏱️ Server Timeout");
    }

    throw err;
  }
};

// ==============================
// 👤 MANDANTEN
// ==============================

export const getMandanten = async () => {
  const data = await apiFetch("/mandanten");
  return data?.data || {};
};

export const addMandantAPI = (data) =>
  apiFetch("/mandanten", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data)
  });

export const updateMandantAPI = (name, data) =>
  apiFetch(`/mandanten/${encodeURIComponent(name)}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data)
  });

export const deleteMandantAPI = (name) =>
  apiFetch(`/mandanten/${encodeURIComponent(name)}`, {
    method: "DELETE"
  });

// ==============================
// 📋 AUFGABEN
// ==============================

export const getAufgabenMandant = (name) =>
  apiFetch(`/mandanten/${encodeURIComponent(name)}/aufgaben`);

export const addAufgabeAPI = (name, data) =>
  apiFetch(`/mandanten/${encodeURIComponent(name)}/aufgaben`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data)
  });

export const toggleAufgabeAPI = (id) =>
  apiFetch(`/aufgaben/${id}/erledigen`, {
    method: "POST"
  });

// ==============================
// 🕒 TIMELINE
// ==============================

export const getTimeline = (name) =>
  apiFetch(`/timeline/${encodeURIComponent(name)}`);

// ==============================
// 📧 EMAIL (AI READY)
// ==============================

export const getEmailPreview = (name) =>
  apiFetch(`/email/${encodeURIComponent(name)}`);

export const sendEmail = (name) =>
  apiFetch(`/email-senden/${encodeURIComponent(name)}`, {
    method: "POST"
  });

// ==============================
// 📄 DOKUMENTE
// ==============================

export const addDokument = (mandant, dokument) =>
  apiFetch(`/dokumente?mandant=${encodeURIComponent(mandant)}&dokument=${encodeURIComponent(dokument)}`, {
    method: "POST"
  });

export const toggleDokument = (mandant, dokument) =>
  apiFetch(`/dokumente/${encodeURIComponent(mandant)}/toggle?dokument=${encodeURIComponent(dokument)}`, {
    method: "POST"
  });

// ==============================
// 📊 DASHBOARD / ENGINE
// ==============================

export const getHeute = () => apiFetch("/heute");

export const getEmpfehlungen = () => apiFetch("/empfehlungen");

export const getPrioritaeten = () => apiFetch("/prioritaeten");

export const getKpis = () => apiFetch("/kpi");

export const getDecisions = () => apiFetch("/decisions");

// ==============================
// 🤖 ENGINE CONTROL
// ==============================

export const runEngine = () =>
  apiFetch("/engine/run", {
    method: "POST"
  });
