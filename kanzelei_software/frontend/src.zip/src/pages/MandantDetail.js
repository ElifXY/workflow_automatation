import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";

import {
  getMandanten,
  getAufgabenMandant,
  addAufgabeAPI,
  toggleAufgabeAPI,
  getTimeline
} from "../api";

// ==============================
// 🎨 UI COMPONENT
// ==============================

const Card = ({ children, color = "#ddd" }) => (
  <div style={{
    background: "#fff",
    padding: "14px",
    borderRadius: "12px",
    borderLeft: `5px solid ${color}`,
    boxShadow: "0 2px 6px rgba(0,0,0,0.05)",
    marginBottom: "10px"
  }}>
    {children}
  </div>
);

// ==============================
// 🚀 COMPONENT
// ==============================

function MandantDetail() {

  const { name } = useParams();

  const [mandant, setMandant] = useState(null);
  const [aufgaben, setAufgaben] = useState([]);
  const [timeline, setTimeline] = useState([]);

  const [beschreibung, setBeschreibung] = useState("");
  const [frist, setFrist] = useState("");

  const [loading, setLoading] = useState(true);

  // ==============================
  // 📥 LOAD ALL (ROBUST)
  // ==============================

  const ladeAlles = async () => {
    try {
      setLoading(true);

      const mandantenData = await getMandanten();

      if (!mandantenData || !mandantenData[name]) {
        setMandant(null);
        return;
      }

      setMandant(mandantenData[name]);

      const a = await getAufgabenMandant(name);
      setAufgaben(Array.isArray(a) ? a : []);

      const t = await getTimeline(name);
      setTimeline(Array.isArray(t) ? t : []);

    } catch (e) {
      console.error("Fehler:", e);
      alert("Fehler beim Laden: " + e.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    ladeAlles();
  }, [name]);

  // ==============================
  // ➕ AUFGABE (OPTIMISTIC)
  // ==============================

  const addAufgabe = async () => {

    if (!beschreibung || !frist) {
      alert("Bitte alles ausfüllen");
      return;
    }

    const temp = {
      id: Date.now(),
      beschreibung,
      frist,
      erledigt: false
    };

    // 🔥 sofort anzeigen
    setAufgaben(prev => [temp, ...prev]);

    try {
      await addAufgabeAPI(name, { beschreibung, frist });

      setBeschreibung("");
      setFrist("");

      ladeAlles(); // sync mit backend

    } catch (e) {
      alert("Fehler: " + e.message);
      ladeAlles(); // rollback
    }
  };

  // ==============================
  // ✅ TOGGLE (OPTIMISTIC)
  // ==============================

  const toggle = async (id) => {

    // 🔥 sofort UI ändern
    setAufgaben(prev =>
      prev.map(a =>
        a.id === id ? { ...a, erledigt: !a.erledigt } : a
      )
    );

    try {
      await toggleAufgabeAPI(id);
    } catch (e) {
      alert("Fehler: " + e.message);
      ladeAlles(); // rollback
    }
  };

  // ==============================
  // 📅 HELPERS
  // ==============================

  const formatDate = (dateStr) => {
    if (!dateStr) return "-";
    return new Date(dateStr).toLocaleDateString();
  };

  const getStatus = (fristStr) => {
    const heute = new Date();
    const f = new Date(fristStr);

    const diff = (f - heute) / (1000 * 60 * 60 * 24);

    if (diff < 0) return { text: "🔴 Überfällig", color: "#f44336" };
    if (diff <= 2) return { text: "🟠 Bald fällig", color: "#ff9800" };

    return { text: "🟢 OK", color: "#4caf50" };
  };

  // ==============================
  // ⏳ LOADING
  // ==============================

  if (loading) {
    return <p style={{ padding: "20px" }}>Lade Mandant...</p>;
  }

  // ==============================
  // ❌ NICHT GEFUNDEN FIX
  // ==============================

  if (!mandant) {
    return (
      <div style={{ padding: "20px" }}>
        <h2>❌ Mandant nicht gefunden</h2>
        <p>{name}</p>
      </div>
    );
  }

  // ==============================
  // 🎯 UI
  // ==============================

  return (
    <div style={{
      padding: "20px",
      fontFamily: "Arial",
      background: "#f5f7fa",
      minHeight: "100vh"
    }}>

      <h2>👤 {name}</h2>

      <Card>
        <p>💰 Umsatz: {mandant.umsatz || 0} €</p>
        <p>📧 {mandant.email || "Keine Email"}</p>
      </Card>

      {/* ============================== */}
      {/* 📋 AUFGABEN */}
      {/* ============================== */}

      <h3>📋 Aufgaben</h3>

      {aufgaben.length === 0 && (
        <p style={{ color: "#777" }}>Keine Aufgaben vorhanden</p>
      )}

      {aufgaben.map((a) => {

        const status = getStatus(a.frist);

        return (
          <Card key={a.id} color={status.color}>

            <input
              type="checkbox"
              checked={!!a.erledigt}
              onChange={() => toggle(a.id)}
              style={{ marginRight: "10px" }}
            />

            <strong style={{
              textDecoration: a.erledigt ? "line-through" : "none"
            }}>
              {a.beschreibung}
            </strong>

            <br />

            <small>
              📅 {formatDate(a.frist)} | {status.text}
            </small>

          </Card>
        );
      })}

      {/* ============================== */}
      {/* ➕ NEUE AUFGABE */}
      {/* ============================== */}

      <h3>➕ Neue Aufgabe</h3>

      <input
        placeholder="Beschreibung"
        value={beschreibung}
        onChange={(e) => setBeschreibung(e.target.value)}
        style={{ marginRight: "10px" }}
      />

      <input
        type="date"
        value={frist}
        onChange={(e) => setFrist(e.target.value)}
        style={{ marginRight: "10px" }}
      />

      <button onClick={addAufgabe}>
        Hinzufügen
      </button>

      {/* ============================== */}
      {/* 🕒 TIMELINE */}
      {/* ============================== */}

      <h3 style={{ marginTop: "40px" }}>🕒 Timeline</h3>

      {timeline.length === 0 && (
        <p style={{ color: "#777" }}>Keine Aktivitäten</p>
      )}

      {timeline.map((t, i) => (
        <Card key={i} color="#2196f3">
          <strong>{t.type}</strong><br />
          {t.text}<br />
          <small>{formatDate(t.date)}</small>
        </Card>
      ))}

    </div>
  );
}

export default MandantDetail;